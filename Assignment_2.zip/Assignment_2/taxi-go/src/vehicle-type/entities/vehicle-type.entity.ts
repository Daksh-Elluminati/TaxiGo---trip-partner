export class VehicleType {}
